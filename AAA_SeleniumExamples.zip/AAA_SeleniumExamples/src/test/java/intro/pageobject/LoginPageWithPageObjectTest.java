package intro.pageobject;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class LoginPageWithPageObjectTest
{
    WebDriver driver;

    @BeforeAll
    public static void init()
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");
    }

    @BeforeEach
    public void setUp()
    {
        driver = new FirefoxDriver();
    }

    @AfterEach
    public void tearDown()
    {
        driver.quit();
    }

    @Test
    public void testLoginFunctionality() throws InterruptedException 
    {
        // ARRANGE
        LoginPage loginPage = new LoginPage(driver);
                
        // ACT
        LandingPage landingPage = loginPage.login("Peter", "Lustig");            
        Thread.sleep(2_000);
        
        // ASSERT
        assertTrue(landingPage.isLoadedCorrectly());
    }
}