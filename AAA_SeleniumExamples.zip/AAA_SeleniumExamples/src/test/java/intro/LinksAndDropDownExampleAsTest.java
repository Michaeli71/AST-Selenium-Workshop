package intro;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class LinksAndDropDownExampleAsTest
{
    WebDriver driver;

    @BeforeAll
    public static void init()
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");
    }

    @BeforeEach
    public void setUp()
    {
        driver = new FirefoxDriver();
    }

    @AfterEach
    public void tearDown()
    {
        driver.quit();
    }

    @Test
    public void testSelectFunctionality()
    {
        // ARRANGE
        driver.get("file:///Users/michaelinden/Selenium-HTML-FILES/LinksAndDropDownExample.html");
    
        // ACT
        driver.findElement(By.linkText("Heise")).click();
        driver.navigate().back();
    
        new WebDriverWait(driver, 2).until(presenceOfElementLocated(By.id("colors")));
        Select selectByValue = new Select(driver.findElement(By.id("colors")));
        selectByValue.selectByValue("green");
    
        Select selectByVisibleText = new Select(driver.findElement(By.id("fruits")));
        selectByVisibleText.selectByVisibleText("Lime");
    
        // ASSERT
        assertAll(() -> assertEquals("Testing Select Class", driver.getTitle()), // on the right page
                  () -> assertEquals("Green", selectByValue.getFirstSelectedOption().getText()),
                  () -> assertEquals("Lime", selectByVisibleText.getFirstSelectedOption().getText()));
    }
}