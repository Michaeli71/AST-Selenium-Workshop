package intro;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RadioAndChekcsExampleAsTest
{
    WebDriver driver;

    @BeforeAll
    public static void init()
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");
    }

    @BeforeEach
    public void setUp()
    {
        driver = new FirefoxDriver();
    }

    @AfterEach
    public void tearDown()
    {
        driver.quit();
    }

    @Test
    public void testRadioAndCheckFunctionality()
    {
        // ARRANGE
        driver.get("file:///Users/michaelinden/Selenium-HTML-FILES/RadioCheckExample.html");
        driver.manage().window().maximize();
    
        // ACT
        WebElement radio1 = driver.findElement(By.id("radio-1"));
        WebElement radio2 = driver.findElement(By.id("radio-2"));
        radio1.click();
        radio2.click();
    
        WebElement check1 = driver.findElement(By.id("check-1"));
        check1.click();
    
        // ASSERT
        assertAll(() -> assertFalse(radio1.isSelected(), "Radio 1 should be inactive"),
                  () -> assertTrue(radio2.isSelected(), "Radio 1 should be active"),
                  () -> assertTrue(check1.isSelected(), "Check should be selected"));
    }
}