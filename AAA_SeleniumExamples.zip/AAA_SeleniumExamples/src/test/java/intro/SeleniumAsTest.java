package intro;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
class SeleniumAsTest
{
    WebDriver driver;

    @BeforeAll
    public static void init()
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");
    }

    @BeforeEach
    public void initDriver()
    {
        driver = new FirefoxDriver();
    }

    @AfterEach
    public void closeWindowsAndFreeResourcen()
    {
        driver.quit();
    }
}