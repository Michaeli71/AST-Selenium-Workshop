package selenium.solutions;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex03_GoogleSearchAsTest
{
    WebDriver driver;

    @BeforeAll
    public static void init()
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");
    }
    
    @BeforeEach
    public void initDriver()
    {
        driver = new FirefoxDriver();
    }

    @AfterEach
    public void closeWindowsAndFreeResourcen()
    {
        driver.quit();
    }
    
    @Test
    public void testGoogleSearch()
    {
        driver.get("http://www.google.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        //driver.findElement(By.name("q")).sendKeys("Java Profi");
        driver.findElement(By.name("q")).sendKeys("JUnit 5");
        
        // Wait for suggestions box to be appear for 20 seconds
        WebDriverWait wait = new WebDriverWait(driver, 20);
        //wait.until(ExpectedConditions.presenceOfElementLocated(By.className("sbdd_b")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("erkvQe")));
        //WebElement list = driver.findElement(By.className("sbdd_b"));
        WebElement list = driver.findElement(By.className("erkvQe"));
        
        final List<WebElement> rows = list.findElements(By.tagName("li"));
        for (WebElement elem : rows)
        {
            System.out.println(elem.getText());
        }
        
        assertTrue(rows.size() > 7);
    }
}