package selenium.solutions;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex04_HomePageSolutionTest
{
    private static WebDriver driver;

    @BeforeAll
    public static void setUp()
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        driver = new FirefoxDriver();
    }

    @AfterAll
    public static void tearDown()
    {
        driver.quit();
    }

    @Test
    public void searchForJavaReturnsResults()
    {
        Ex04_HomePageSolution home = new Ex04_HomePageSolution(driver);
        home.open();
        home.searchFor("java");

        Ex04_ResultsPage results = new Ex04_ResultsPage(driver);
        results.waitToShowUpWithResults();

        assertTrue(results.isOpen());
        assertTrue(results.count() > 0);
    }

    @Test
    public void searchFor_JavaProfi_Does_Not_ReturnResults()
    {
        Ex04_HomePageSolution home = new Ex04_HomePageSolution(driver);
        home.open();
        home.searchFor("Java Profi");

        Ex04_ResultsPage results = new Ex04_ResultsPage(driver);

        assertTrue(results.isOpen());
        assertTrue(results.checkIfNothingFound());
    }

    @Test
    public void searchForPythonReturnsResults() throws InterruptedException
    {
        Ex04_HomePageSolution home = new Ex04_HomePageSolution(driver);
        home.open();
        home.searchFor("python");

        Thread.sleep(20_000);
        
        Ex04_ResultsPage results = new Ex04_ResultsPage(driver);
        results.waitToShowUpWithResults();

        assertTrue(results.isOpen());
        assertTrue(results.count() > 0);
    }

    @Test
    public void openDetailsForFirstPythonResult()
    {
        Ex04_HomePageSolution home = new Ex04_HomePageSolution(driver);
        home.open();
        home.searchFor("python");

        Ex04_ResultsPage results = new Ex04_ResultsPage(driver);

        // als Kür
        /*
        results.select(1);
        
        DetailsPage details = new DetailsPage(driver); 
        
        assertTrue(details.isOpen());
        */
    }
}
