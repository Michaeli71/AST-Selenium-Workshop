package selenium.exercises;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex04_HomePageExercise
{
    private WebDriver    driver;

    private final String URL        = "http://www.vpl.ca";

    private final String TITLE      = "Vancouver Public Library";

    private final By     SEARCH_BOX = By.id("globalQuery");

    private final By     SEARCH_BTN = By.xpath("//input[@class='search_button']");

    public Ex04_HomePageExercise(WebDriver driver)
    {
        this.driver = driver;
    }

    public void open()
    {
        // code that opens the page
    }

    public boolean isDisplayed()
    {
        //code that checks if the page is displayed
        return false;
    }

    public void searchFor(String keyword)
    {
        //code that searches for a keyword
    }
}
