package selenium.exercises;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex01_FacebookLogin
{
    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        WebDriver driver = new FirefoxDriver();

        try
        {
            driver.get("http://www.facebook.com");

            acceptCookiesPolicy(driver);
           
            // TODO
            Thread.sleep(2_000);
        }
        finally
        {
            driver.close();
        }
    }
    
    private static void acceptCookiesPolicy(WebDriver driver) {
        //nasty: constantly changing IDs / cssSelectors for cookies => 
        //WebElement cookieInfo = driver.findElement(By.linkText("Optionale Cookies ablehnen"));
        //WebElement cookieInfo = driver.findElement(By.partialLinkText("Optionale Cookies ablehnen"));          
        
        // get rid of cookie info
        By cookies = By.xpath("//*[contains(@title, \"Alle Cookies erlauben\")]");
        driver.findElement(cookies).click();        
        driver.switchTo().defaultContent();
    }
}