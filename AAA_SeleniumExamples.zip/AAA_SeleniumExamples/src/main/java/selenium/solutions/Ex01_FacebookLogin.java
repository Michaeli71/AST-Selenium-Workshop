package selenium.solutions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex01_FacebookLogin
{
    private static final String ACCEPT_COOKIES_BUTTON_X_PATH = null;
    private static final long TIMEOUT_IN_SECONDS = 2;

    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        WebDriver driver = new FirefoxDriver();

        try
        {            
            driver.get("http://www.facebook.com");
            
           //Thread.sleep(40_000);
            acceptCookiesPolicy(driver);
        
            WebElement emailInput = driver.findElement(By.id("email"));
            WebElement passwordInput = driver.findElement(By.cssSelector("#pass"));
            WebElement anmeldenButton = driver.findElement(By.name("login"));
            
            emailInput.sendKeys("Peter");
            passwordInput.sendKeys("Lustig");

            Thread.sleep(2_000);

            passwordInput.clear();
            emailInput.sendKeys("Unknown");
            passwordInput.sendKeys("NICHT_Lustig");

            Thread.sleep(2_000);

            anmeldenButton.submit();
            
            Thread.sleep(2_000);
        }
        finally
        {
            driver.close();
        }
    }
    
    
    private static void acceptCookiesPolicy(WebDriver driver) {
        //nasty: constantly changing IDs / cssSelectors for cookies => 
        //WebElement cookieInfo = driver.findElement(By.linkText("Optionale Cookies ablehnen"));
        //WebElement cookieInfo = driver.findElement(By.partialLinkText("Optionale Cookies ablehnen"));          
        
        // get rid of cookie info
        By cookies = By.xpath("//*[contains(@title, \"Alle Cookies erlauben\")]");
        driver.findElement(cookies).click();        
        driver.switchTo().defaultContent();
    }
}