package selenium.solutions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex04_ResultsPage
{
    private WebDriver    driver;

    private final String URL            = "https://vpl.bibliocommons.com/v2/search";

    private final By     RESULT_COUNT   = By
                    // OLD
                    //.xpath("/html/body/div/div/div/div[6]/div/div/div/div[2]/div[2]/section/section[1]/div[2]/span");
                    //.xpath("/html/body/div[1]/div/div/main/div/div/div/div[2]/div[2]/section/section[1]/nav/span");
                    //.cssSelector("nav.cp-pagination:nth-child(5) > span:nth-child(1)");
                    .className("cp-pagination-label");
    
    private final By     NOT_FOUND_INFO = By.cssSelector(".empty-search-sub-title");

    Ex04_ResultsPage(WebDriver driver)
    {
        this.driver = driver;
    }

    public boolean isOpen()
    {
        return driver.getCurrentUrl().contains(URL);
    }

    public void waitToShowUpWithResults()
    {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(RESULT_COUNT));
    }
    
    public int count()
    {
        WebElement resultInfo = driver.findElement(RESULT_COUNT);
        String info = resultInfo.getText();
        // 1 to 10 of 365 results
        final String[] tokens = info.split(" ");

        final int resultCount = Integer.parseInt(tokens[4]);
        return resultCount;
    }

    public boolean checkIfNothingFound()
    {
        WebElement notFoundInfo = driver.findElement(NOT_FOUND_INFO);
        String info = notFoundInfo.getText();

        return info.contains("Nothing found for");
    }
}
