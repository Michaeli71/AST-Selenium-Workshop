package intro;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class FirstSeleniumAmazonSearchWithChrome
{
    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.chrome.driver", "/opt/WebDriver/bin/chromedriver");

        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, 2, 0);
        try
        {
            driver.get("https://amazon.de/");
            driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Java Profi" + Keys.ENTER);

            Thread.sleep(2_000);

            WebElement firstResult = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("h2>a")));
            System.out.println(firstResult.getAttribute("textContent"));
        }
        finally
        {
            driver.quit();
        }
    }
}
