package intro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RadioAndCheckExample
{
    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        WebDriver driver = new FirefoxDriver();

        try
        {
            driver.get("file:///Users/michaelinden/Selenium-HTML-FILES/RadioCheckExample.html");
            driver.manage().window().maximize();

            WebElement radio1 = driver.findElement(By.id("radio-1"));
            WebElement radio2 = driver.findElement(By.id("radio-2"));
            radio1.click();
            radio2.click();

            WebElement check1 = driver.findElement(By.id("check-1"));
            check1.click();

            String checkState = check1.isSelected() ? "ON" : "OFF";
            System.out.println("Checkbox is Toggled " + checkState);
        }
        finally
        {
            driver.quit();
        }
    }
}