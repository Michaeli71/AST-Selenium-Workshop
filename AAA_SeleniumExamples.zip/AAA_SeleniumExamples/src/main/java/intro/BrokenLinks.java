package intro;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class BrokenLinks
{
    public static void main(String[] args)
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        final WebDriver driver = new FirefoxDriver();

        try
        {
            driver.get("file:///Users/michaelinden/Selenium-HTML-FILES/SomeBrokenLinksExample.html");

            final List<WebElement> links = getAllLinksFromPage(driver);
            final Iterator<WebElement> it = links.iterator();
            while (it.hasNext())
            {
                final String url = it.next().getAttribute("href");

                final String state = checkValidityOfUrl(url) ? "VALID" : "BROKEN";
                System.out.println(url + " is " + state);
            }
        }
        finally
        {
            driver.quit();
        }
    }

    private static boolean checkValidityOfUrl(String url)
    {
        if (url == null || url.isEmpty())
            return false;

        try
        {
            final HttpURLConnection huc = (HttpURLConnection) (new URL(url).openConnection());
            huc.setRequestMethod("HEAD");
            huc.connect();

            final int respCode = huc.getResponseCode();

            return respCode >= 200 && respCode < 400;
        }
        catch (IOException e)
        {
        }
        return false;
    }

    private static List<WebElement> getAllLinksFromPage(final WebDriver driver)
    {
        List<WebElement> links = driver.findElements(By.tagName("a"));
        return links;
    }
}